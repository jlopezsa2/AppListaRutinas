const express = require('express');
const router = express.Router();
const Usuario = require('../modelos/usuario');



function usuariosAPI(app) {
    app.use('/api/usuarios', router)

        // Obtener todos
        router.get('/', async (req, res) => {
        const usuarios = await Usuario.find();
        res.json(usuarios);
        });

        // Crear nuevo
        router.post('/', async (req, res) => {
        const nuevoUsuario = new Usuario(req.body);
        
        await nuevoUsuario.save();
        res.json(nuevoUsuario);
        });

        // Obtener uno por ID
        /*router.get('/:id', async (req, res) => {
        const usuario = await Usuario.findOne({ id: req.params.id });
        res.json(usuario);
        });*/

        router.get('/:id', async (req, res) => {
            const usuario = await Usuario.findOne({ id: req.params.id });
            if (!usuario) return res.status(404).json({ message: 'Usuario no encontrado' });
            res.json(usuario);
        });




        // Actualizar un usuario completo
        router.put('/:id', async (req, res) => {
        const usuario = await Usuario.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
        res.json(usuario);
        });

        /*router.put('/usuarios/:id', async (req, res) => {
        const id = req.params.id;
        const nuevosDatos = req.body;

        try {
            const usuarioActualizado = await Usuario.findOneAndUpdate(
            { id: parseInt(id) },
            nuevosDatos,
            { new: true }
            );
            res.json(usuarioActualizado);
        } catch (error) {
            res.status(500).json({ error: 'Error actualizando el usuario' });
        }
        });*/




    router.delete('/:id', async (req, res) => {
            try {
            const usuarioEliminado = await Usuario.findOneAndDelete({ id: req.params.id });
            if (!usuarioEliminado) {
            return res.status(404).json({ mensaje: 'Usuario no encontrado' });
            }
            res.json({ mensaje: 'Usuario eliminado', usuario: usuarioEliminado });
        } catch (error) {
            res.status(500).json({ mensaje: 'Error al eliminar usuario', error });
        }
    });



router.put('/:usuarioId/rutinas/:rutinaId/subtareas/:subtareaId', async (req, res) => {
  try {
    const { usuarioId, rutinaId, subtareaId } = req.params;
    const nuevosDatos = req.body;

    const usuario = await Usuario.findOne({ id: parseInt(usuarioId) });

    if (!usuario) {
      return res.status(404).json({ mensaje: 'Usuario no encontrado' });
    }

    const rutina = usuario.rutinas.find(r => r.id === parseInt(rutinaId));
    if (!rutina) {
      return res.status(404).json({ mensaje: 'Rutina no encontrada' });
    }

    const subtarea = rutina.subtareas.find(s => s.id === parseInt(subtareaId));
    if (!subtarea) {
      return res.status(404).json({ mensaje: 'Subtarea no encontrada' });
    }

    // Actualizar solo los campos que llegan
    Object.assign(subtarea, nuevosDatos);

    await usuario.save();

    res.json({ mensaje: 'Subtarea actualizada', subtarea });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al actualizar la subtarea', error });
  }
});


}



module.exports = usuariosAPI;
