const fs = require('fs')
const MongoLib = require('../lib/mongo')
const Ciudad = require('../modelos/usuario')


class UsuariosService{
    constructor(){
        this.coleccion = 'usuarios'
        this.mongoDB = new MongoLib()
    }
    async getUsuarios(){
        try {
            // let ciudades = await fs.promises.readFile("./utils/mocks/ciudades.json");
            const usuarios = await this.mongoDB.getUsuarios(this.coleccion)
            return usuarios;
        } catch(error){
            console.log('error recuperando usuarios')
        }

    }
    async addUsuario(usuario) {
        /*try {
            const insertedId = await this.mongoDB.anadirCiudad(this.coleccion, ciudad);
            return { id: insertedId, ...ciudad };  // Solo devuelves el objeto original con el _id añadido
        } catch (error) {
            throw error;
        }*/

            const usuarioCreadoId = await this.mongoDB.anadirUsuario(this.coleccion, usuario);
            return usuarioCreadoId || [];

    }



    async borrarUsuario(usuarioId) {
        const usuarioBorradoId = await this.mongoDB.borrarUsuario(this.coleccion, usuarioId);
        return usuarioBorradoId || [];
    }




    
} 

module.exports = CiudadesService