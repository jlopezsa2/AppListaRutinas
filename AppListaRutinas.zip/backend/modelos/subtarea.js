
const SubtareaSchema = {
  id: Number,
  nombre: { type: String, required: true },
  completada: { type: Boolean, default: false },
  pictogramaUrl: String,
  horaurl: String,
  carita: String
};

module.exports = SubtareaSchema; 

