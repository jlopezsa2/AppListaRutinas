/*const RutinaSchema = require('./rutina');

const Usuario = {
  id: { type: Number, required: true, unique: true },
  nombre: { type: String, required: true },
  rutinas: [RutinaSchema]
};

module.exports = Usuario;*/

const mongoose = require('mongoose');

const SubtareaSchema = new mongoose.Schema({
  id: Number,
  nombre: String,
  completada: Boolean,
  pictogramaUrl: String,
  horaurl: String,
  carita: String
});

const RutinaSchema = new mongoose.Schema({
  id: Number,
  nombre: String,
  subtareas: [SubtareaSchema]
});

const UsuarioSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  nombre: { type: String, required: true },
  rutinas: [RutinaSchema]
});

const Usuario = mongoose.model('Usuario', UsuarioSchema);
module.exports = Usuario;





