
const Subtareas = require('./subtarea');

const RutinaSchema = {
  id: Number,
  nombre: { type: String, required: true },
  subtareas: [Subtareas]
};

module.exports = RutinaSchema;
