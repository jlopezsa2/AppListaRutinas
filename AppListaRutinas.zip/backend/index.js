const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const usuariosAPI = require('./rutas/usuarios');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;


mongoose.connect('mongodb+srv://jlopezsainf:VDxj4P5ioz6UeNGQ@serviciosyplataformaswe.dmzlh.mongodb.net/?retryWrites=true&w=majority&appName=ServiciosyPlataformasWeb', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('Conectado a MongoDB'))
.catch((err) => console.error(' Error conectando a MongoDB:', err));


app.use(cors());
app.use(express.json());


app.use(express.static(path.resolve(__dirname, '../frontend/dist/app-lista-rutinas/browser')));


usuariosAPI(app);


app.get(/.*/, (req, res) => {
  res.sendFile(path.resolve(__dirname, '../frontend/dist/app-lista-rutinas/browser/index.html'));
});


app.listen(PORT, () => {
  console.log(`🚀 Servidor escuchando en http://localhost:${PORT}`);
});
