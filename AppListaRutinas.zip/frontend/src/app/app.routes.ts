import { Routes } from '@angular/router';
import { ListadoUsuariosComponent } from './componentes/listado-usuarios/listado-usuarios.component';
import { RutinasusuarioComponent } from './componentes/rutinasusuario/rutinasusuario.component';
import { ResumenComponent } from './componentes/resumen/resumen.component';

export const routes: Routes = [

    {path: '', component: ListadoUsuariosComponent},
    {path: 'usuariosRutinas/:id', component: RutinasusuarioComponent},
    {path: 'resumenTareas/:id', component: ResumenComponent},
    {path: '**', component: ListadoUsuariosComponent},
];
