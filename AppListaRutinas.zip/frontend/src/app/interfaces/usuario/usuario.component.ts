export interface Usuario {
  _id?: string;
  id: number;
  nombre: string;
  rutinas: string[];
}
