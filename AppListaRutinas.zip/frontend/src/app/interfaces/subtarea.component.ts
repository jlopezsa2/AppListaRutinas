export interface Subtarea {
  id: number;
  nombre: string;
  completada: boolean;
  pictogramaUrl: string;
  horaurl: string;
  carita?: string;
}