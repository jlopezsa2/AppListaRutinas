import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { UsuariosService } from '../../servicios/usuarios.service';
import { Location } from '@angular/common';
import { RutinasService } from '../../servicios/rutinas.service';
import { ListadoRutinasComponent } from "../listado-rutinas/listado-rutinas.component";
import { SubtareasService } from '../../servicios/subtareas.service';

@Component({
  selector: 'app-rutinasusuario',
  imports: [RouterLink, ListadoRutinasComponent],
  templateUrl: './rutinasusuario.component.html',
  styleUrl: './rutinasusuario.component.css'
})
export class RutinasusuarioComponent {
  route = inject(ActivatedRoute);
  usuariosServicio = inject(UsuariosService);
  rutinasServicio = inject(RutinasService);
  activatedRoute = inject(ActivatedRoute);
  usuario: any = {};
  subtareasService = inject(SubtareasService)
  
  constructor() {
    
    const idusuarioString = this.activatedRoute.snapshot.paramMap.get('id')!;
    const idusuario = Number(idusuarioString);
    this.usuario = this.usuariosServicio.obtenerUsuario(idusuario.toString());
   
   
}


ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    
    if (id) {
      this.usuariosServicio.obtenerUsuarioDesdeBD(id).subscribe((usuario) => {
        this.usuario = usuario;
        console.log('Usuario cargado:', usuario);
      });
    }
  }



  agregarRutina() {
    const nombre = prompt("Nombre de la nueva rutina:");
    console.log(nombre)
    if (nombre) {
      this.rutinasServicio.agregarRutina(this.usuario, nombre);
    }
  }

  
}
