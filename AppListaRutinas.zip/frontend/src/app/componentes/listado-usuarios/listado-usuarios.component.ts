import { Component, inject, OnInit } from '@angular/core';
import { UsuariosService } from '../../servicios/usuarios.service';
import { UsuariosComponent } from "../usuario/usuario.component";
import { Usuario } from '../../interfaces/usuario/usuario.component';

@Component({
  selector: 'app-listado-usuarios',
  standalone: true,
  imports: [UsuariosComponent],
  templateUrl: './listado-usuarios.component.html',
  styleUrl: './listado-usuarios.component.css'
})
export class ListadoUsuariosComponent implements OnInit {
  usuariosService = inject(UsuariosService);
   usuarios: any[] = [];
  listadoUsuarios: any[] = [];
  constructor() {

   
  }
  ngOnInit(): void {
    this.usuariosService.cargarUsuarios();  
    
    // Esperamos un momento a que los usuarios se carguen
    setTimeout(() => {
      this.listadoUsuarios = this.usuariosService.obtenerUsuarios();
      
    }, 400); 
  }

  agregaruser(): void {
    const nombreU = prompt("Usuario:");

    if (nombreU != null && nombreU.trim() !== '') {
      this.usuariosService.agregarUsuario(nombreU);
      
      // Esperamos un momento para reflejar el cambio en pantalla
      setTimeout(() => {
        this.listadoUsuarios = this.usuariosService.obtenerUsuarios();
      }, 400);
    }
  }



 
onUsuarioEliminado(id: string): void {
    this.usuarios = this.usuarios.filter(u => u._id !== id);
  }




}
