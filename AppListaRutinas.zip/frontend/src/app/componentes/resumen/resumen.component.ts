import { Component, inject, signal, effect } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UsuariosService } from '../../servicios/usuarios.service';

@Component({
  selector: 'app-resumen',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './resumen.component.html',
  styleUrls: ['./resumen.component.css']
})
export class ResumenComponent {
  private usuariosService = inject(UsuariosService);
  private route = inject(ActivatedRoute);

  usuarioId = signal<number>(0);
  subtareasUsuario = signal<any[]>([]); // Almacenaremos las subtareas aquí

  constructor() {
    effect(() => {
      const id = this.route.snapshot.paramMap.get('id');
      if (id) {
        this.usuarioId.set(Number(id));
        this.obtenerSubtareasUsuario();
      }
    });
  }

  obtenerSubtareasUsuario() {
    const usuario = this.usuariosService.obtenerUsuario(this.usuarioId().toString());
    if (usuario && usuario.rutinas) {
      const subtareas: any[] = [];
      usuario.rutinas.forEach((rutina: any) => {
        rutina.subtareas.forEach((subtarea: any) => {
          subtareas.push(subtarea);
        });
      });
      this.subtareasUsuario.set(subtareas);
    }
  }
}
