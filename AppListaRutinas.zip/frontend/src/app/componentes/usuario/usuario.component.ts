import { Component, inject, Input, Output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { UsuariosService } from '../../servicios/usuarios.service';
import {EventEmitter} from '@angular/core';
@Component({
  selector: 'app-usuario',
  imports: [RouterLink],
  templateUrl: './usuario.component.html',
  styleUrl: './usuario.component.css'
})
export class UsuariosComponent {

  @Input() usuario:any;
  @Output() usuarioEliminado = new EventEmitter<string>();
  router = inject(Router)

  constructor(private usuariosService: UsuariosService) {}

  verUsuario(usuario:any){
    this.router.navigate(['usuarios'])
  }

  eliminarUsuario() {
    if (confirm(`¿Seguro que quieres eliminar a ${this.usuario.nombre}?`)) {
      this.usuariosService.borrarUsuario(this.usuario.id).subscribe(() => {
        this.usuarioEliminado.emit(this.usuario._id); 
        window.location.reload(); 
      });
    }
  }




}
