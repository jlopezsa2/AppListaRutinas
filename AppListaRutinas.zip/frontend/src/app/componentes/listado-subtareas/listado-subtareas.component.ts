import { Component, Input } from '@angular/core';
import { SubtareaComponent } from '../subtarea/subtarea.component';

@Component({
  selector: 'app-listado-subtareas',
  standalone: true,
  imports: [SubtareaComponent],
  templateUrl: './listado-subtareas.component.html',
  styleUrl: './listado-subtareas.component.css'
})
export class ListadoSubtareasComponent {
  @Input() subtareas: any[] = [];
  @Input() usuarioId!: number;
  @Input() rutinaId!: number;
}
