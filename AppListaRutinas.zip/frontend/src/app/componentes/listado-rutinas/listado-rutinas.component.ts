import { Component, inject, Input } from '@angular/core';
import { SubtareasService } from '../../servicios/subtareas.service';
import { RutinaComponent } from "../rutina/rutina.component";

@Component({
  selector: 'app-listado-rutinas',
  imports: [RutinaComponent],
  templateUrl: './listado-rutinas.component.html',
  styleUrl: './listado-rutinas.component.css'
})
export class ListadoRutinasComponent {

  @Input() rutinas: any[] = [];
  @Input() usuarioId!: number;

}
