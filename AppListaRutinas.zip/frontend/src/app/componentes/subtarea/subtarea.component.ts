import { Component, Input } from '@angular/core';
import { UsuariosService } from '../../servicios/usuarios.service';

@Component({
  selector: 'app-subtarea',
  standalone: true,
  imports: [],
  templateUrl: './subtarea.component.html',
  styleUrl: './subtarea.component.css'
})
export class SubtareaComponent {
  @Input() subtarea: any = { nombre: '', completada: false };
  @Input() usuarioId!: number;
  @Input() rutinaId!: number; 

  constructor(private usuariosServicio: UsuariosService) {}

  completarSubtarea() {
  this.subtarea.completada = !this.subtarea.completada;

  this.usuariosServicio.actualizarSubtarea(
    this.usuarioId,
    this.rutinaId,
    this.subtarea.id,
    { completada: this.subtarea.completada }
  ).subscribe({
    next: () => console.log('Subtarea completada guardada'),
    error: (err) => console.error('Error actualizando subtarea', err)
  });
}

seleccionarCarita(tipo: string) {
  this.subtarea.carita = tipo;
  console.log('Carita seleccionada:', tipo);
  console.log('ID de la subtarea:', this.subtarea.id);
  console.log('ID de la rutina:', this.rutinaId);
  console.log('ID del usuario:', this.usuarioId);
  console.log('Carita de la subtarea:', this.subtarea.carita);

  
  this.usuariosServicio.actualizarSubtarea(
    this.usuarioId,
    this.rutinaId,
    this.subtarea.id,
    { carita: tipo }
  ).subscribe({
    next: () => console.log('Carita guardada'),
    complete: () => console.log('Actualización de carita completada'),
    error: (err) => console.error('Error actualizando carita', err)
  });
}




}
