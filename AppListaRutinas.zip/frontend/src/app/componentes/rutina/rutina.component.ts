import { Component, inject, Input, Output } from '@angular/core';
import { SubtareasService } from '../../servicios/subtareas.service';
import { ListadoSubtareasComponent } from "../listado-subtareas/listado-subtareas.component";
import { UsuariosService } from '../../servicios/usuarios.service';


@Component({
  selector: 'app-rutina',
  imports: [ListadoSubtareasComponent],
  templateUrl: './rutina.component.html',
  styleUrl: './rutina.component.css',
  standalone: true
})
export class RutinaComponent {
  
  //@Input() rutina: any;
  @Input() rutina: any = { nombre: '', subtareas: [] };
  @Input() usuarioId!: number;
  
  subtareasService = inject(SubtareasService);
  usuariosService = inject(UsuariosService)


  ngOnInit() {
  console.log('UsuarioId recibido:', this.usuarioId);
}


  /*agregarSubtarea() {
    const nombre = prompt("Nombre de la nueva subtarea:");
    const nombreHora = prompt("Introduce la hora en formato: HH:MM")
   
    if (nombre && nombreHora) {
      console.log('En rutina al pasar usuarioid: ' +this.usuarioId)
       console.log('En rutina al pasar la rutina: ' + this.rutina)
      this.subtareasService.agregarSubtarea(this.usuarioId, this.rutina, nombre, nombreHora);
      this.usuariosService.guardarUsuarios()
      this.usuariosService.obtenerUsuarios()
      
      
    }
  }*/

  agregarSubtarea() {
  const nombre = prompt("Nombre de la nueva subtarea:");
  const nombreHora = prompt("Introduce la hora en formato: HH:MM");

  if (nombre && nombreHora) {
    console.log('En rutina al pasar usuarioid: ' + this.usuarioId);
    console.log('En rutina al pasar la rutina: ', this.rutina);

    this.subtareasService.agregarSubtarea(this.usuarioId, this.rutina, nombre, nombreHora)
    .subscribe({
    next: (nuevaSubtarea) => {
      this.rutina.subtareas.push(nuevaSubtarea); 
    },
    error: (err) => console.error('Error al añadir subtarea:', err)
  });

  }
}





}
