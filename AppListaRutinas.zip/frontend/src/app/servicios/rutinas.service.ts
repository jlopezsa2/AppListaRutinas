import { inject, Injectable } from '@angular/core';
import { UsuariosService } from './usuarios.service';

@Injectable({
  providedIn: 'root'
})
export class RutinasService {

  private STORAGE_KEY = 'rutinas';
  usuariosService = inject(UsuariosService)
  constructor() {

  }


agregarRutina(usuario: any, nombre: string) {
    const nuevaRutina = { id: Date.now(), nombre, subtareas: [] };
    usuario.rutinas.push(nuevaRutina);

    // Actualizar en MongoDB
    this.usuariosService.actualizarUsuario(usuario).subscribe({
      next: updatedUser => {
        console.log('Usuario actualizado con nueva rutina en la BD:', updatedUser);
      },
      error: err => {
        console.error('Error actualizando usuario en la BD:', err);
      }
    });
  }



  guardarRutinas(usuarioId: number, rutinas: any[]) {
    const rutinasGuardadas = JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '{}');
    rutinasGuardadas[usuarioId] = rutinas;
    
  }

  obtenerRutinas(usuario: any) {
    return usuario.rutinas;
  }
}
