import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RutinasService } from './rutinas.service';
import { UsuariosService } from './usuarios.service';
import { Observable } from 'rxjs';

interface Subtarea {
  id: number;
  nombre: string;
  completada: boolean;
  pictogramaUrl: string;
  horaurl: string;
  carita?: string;
}
@Injectable({
  providedIn: 'root'
})
export class SubtareasService {

  constructor(private http: HttpClient, private rutinasService: RutinasService) {

  }
  usuariosService = inject(UsuariosService)


  /*agregarSubtarea(usuarioId: number, rutina: any, nombre: string, nombreHora: string) {
    if (!rutina.subtareas) {
      rutina.subtareas = []; 
    }
  
    
    let nombreHoraLimpio = nombreHora
    
    let horaUrl = `${nombreHoraLimpio}.png`;
    
    if(horaUrl === '13:00.png'){
      horaUrl = '01:00.png'
    }
    if(horaUrl === '13:30.png'){
      horaUrl = '01:30.png'
    }
    if(horaUrl === '14:00.png'){
      horaUrl = '02:00.png'
    }
    if(horaUrl === '14:30.png'){
      horaUrl = '02:30.png' 
    }
    if(horaUrl === '15:00.png'){
      horaUrl = '03:00.png'
    }
    if(horaUrl === '15:30.png'){
      horaUrl = '03:30.png'
    }
    if(horaUrl === '16:00.png'){
      horaUrl = '04:00.png'
    }
    if(horaUrl === '16:30.png'){
      horaUrl = '04:30.png'
    }
    if(horaUrl === '17:00.png'){
      horaUrl = '05:00.png'
    }
    if(horaUrl === '17:30.png'){
      horaUrl = '05:30.png'
    }
    if(horaUrl === '18:00.png'){
      horaUrl = '06:00.png'
    }
    if(horaUrl === '18:30.png'){
      horaUrl = '06:30.png'
    }
    if(horaUrl === '19:00.png'){
      horaUrl = '07:00.png'
    }
    if(horaUrl === '19:30.png'){
      horaUrl = '07:30.png'
    }
    if(horaUrl === '20:00.png'){
      horaUrl = '08:00.png'
    }
    if(horaUrl === '20:30.png'){
      horaUrl = '08:30.png'
    }
    if(horaUrl === '21:00.png'){
      horaUrl = '09:00.png'
    }
    if(horaUrl === '21:30.png'){
      horaUrl = '09:30.png'
    }
    if(horaUrl === '22:00.png'){
      horaUrl = '10:00.png'
    }
    if(horaUrl === '22:30.png'){
      horaUrl = '10:30.png'
    }
    if(horaUrl === '23:00.png'){
      horaUrl = '11:00.png'
    }
    if(horaUrl === '23:30.png'){
      horaUrl = '11:30.png'
    }
    if(horaUrl === '00:00.png'){
      horaUrl = '12:00.png'
    }
    if(horaUrl === '00:30.png'){
      horaUrl = '12:30.png'
    }


    this.obtenerPictograma(nombre, (url) => {
    const nuevaSubtarea = { 
    id: Date.now(), 
    nombre, 
    completada: false, 
    pictogramaUrl: url, 
    horaUrl: horaUrl 
  };
  
  rutina.subtareas.push(nuevaSubtarea);

  
  const usuario = this.usuariosService.obtenerUsuarioPorId(usuarioId);
  if (usuario) {
    this.usuariosService.actualizarUsuario(usuario).subscribe({
      next: (res) => console.log('Usuario actualizado con nueva subtarea'),
      error: (err) => console.error('Error al actualizar usuario con subtarea:', err)
    });
    
  }
});




  }*/

/*agregarSubtarea(usuarioId: number, rutina: any, nombre: string, nombreHora: string) {
  if (!rutina.subtareas) {
    rutina.subtareas = []; 
  }

  let horaUrl = `${nombreHora}.png`;

  const conversionesHoras: { [key: string]: string } = {
    '13:00.png': '01:00.png',
    '13:30.png': '01:30.png',
    '14:00.png': '02:00.png',
    '14:30.png': '02:30.png',
    '15:00.png': '03:00.png',
    '15:30.png': '03:30.png',
    '16:00.png': '04:00.png',
    '16:30.png': '04:30.png',
    '17:00.png': '05:00.png',
    '17:30.png': '05:30.png',
    '18:00.png': '06:00.png',
    '18:30.png': '06:30.png',
    '19:00.png': '07:00.png',
    '19:30.png': '07:30.png',
    '20:00.png': '08:00.png',
    '20:30.png': '08:30.png',
    '21:00.png': '09:00.png',
    '21:30.png': '09:30.png',
    '22:00.png': '10:00.png',
    '22:30.png': '10:30.png',
    '23:00.png': '11:00.png',
    '23:30.png': '11:30.png',
    '00:00.png': '12:00.png',
    '00:30.png': '12:30.png',
  };

  horaUrl = conversionesHoras[horaUrl] || horaUrl;

  this.obtenerPictograma(nombre, (url) => {
    const nuevaSubtarea = { 
      id: Date.now(), 
      nombre, 
      completada: false, 
      pictogramaUrl: url, 
      horaUrl: horaUrl 
    };

    // Añadir la subtarea a la rutina directamente
    rutina.subtareas.push(nuevaSubtarea);

    // ⚠️ Aquí actualizamos el usuario completo con la rutina ya modificada
    const usuario = this.usuariosService.obtenerUsuarioPorId(usuarioId);
    console.log('Usuario a subtarea: ' + usuario)
    if (usuario) {
      // No obtener el usuario de nuevo, simplemente actualizarlo
      this.usuariosService.actualizarUsuario(usuario).subscribe({
        next: (res) => console.log('Usuario actualizado con nueva subtarea'),
        error: (err) => console.error('Error al actualizar usuario con subtarea:', err)
      });
    } else {
      console.error('No se encontró el usuario con ID', usuarioId);
    }
  });
}*/

agregarSubtarea(usuarioId: number, rutina: any, nombre: string, nombreHora: string): Observable<Subtarea> {
  return new Observable<Subtarea>((observer) => {
    console.log('usuario id: ' + usuarioId);
    if (!rutina.subtareas) {
      rutina.subtareas = [];
    }
    
    var horaUrl = `${nombreHora}.png`;

    const conversionesHoras: { [key: string]: string } = {
      '13:00.png': '01:00.png',
      '13:30.png': '01:30.png',
      '14:00.png': '02:00.png',
      '14:30.png': '02:30.png',
      '15:00.png': '03:00.png',
      '15:30.png': '03:30.png',
      '16:00.png': '04:00.png',
      '16:30.png': '04:30.png',
      '17:00.png': '05:00.png',
      '17:30.png': '05:30.png',
      '18:00.png': '06:00.png',
      '18:30.png': '06:30.png',
      '19:00.png': '07:00.png',
      '19:30.png': '07:30.png',
      '20:00.png': '08:00.png',
      '20:30.png': '08:30.png',
      '21:00.png': '09:00.png',
      '21:30.png': '09:30.png',
      '22:00.png': '10:00.png',
      '22:30.png': '10:30.png',
      '23:00.png': '11:00.png',
      '23:30.png': '11:30.png',
      '00:00.png': '12:00.png',
      '00:30.png': '12:30.png',
    };

    horaUrl = conversionesHoras[horaUrl] || horaUrl;
    console.log('horaUrl: ' + horaUrl);
    this.obtenerPictograma(nombre, (url) => {
      const nuevaSubtarea: Subtarea = {
        id: Date.now(),
        nombre,
        completada: false,
        pictogramaUrl: url,
        horaurl: horaUrl,
        carita: "feliz" 
      };

      this.usuariosService.obtenerUsuarioDesdeBackend(usuarioId).subscribe({
        next: (usuario) => {
          const rutinaActualizada = usuario.rutinas.find((r: any) => r.id === rutina.id);

          if (!rutinaActualizada) {
            console.error('No se encontró la rutina en el usuario recibido del backend');
            observer.error('Rutina no encontrada');
            return;
          }

          if (!rutinaActualizada.subtareas) {
            rutinaActualizada.subtareas = [];
          }

          rutinaActualizada.subtareas.push(nuevaSubtarea);

          this.usuariosService.actualizarUsuario(usuario).subscribe({
            next: () => {
              console.log('Subtarea añadida y usuario actualizado correctamente');
              observer.next(nuevaSubtarea); 
              observer.complete(); 
            },
            error: (err) => {
              console.error('Error al actualizar usuario:', err);
              observer.error(err);
            }
          });
        },
        error: (err) => {
          console.error('Error al obtener el usuario desde el backend:', err);
          observer.error(err);
        }
      });
    });
  });
}










  obtenerPictograma(nombre: string, callback: (url: string) => void) {
    const url = `https://api.arasaac.org/v1/pictograms/es/search/${encodeURIComponent(nombre)}`;

    this.http.get<any[]>(url).subscribe(

      response => {
        if (response.length > 0) {
          const id = response[0]._id;
          callback(`https://api.arasaac.org/v1/pictograms/${id}`);
        } else {
          callback('');
        }
      },
      error => {
        console.error('Error obteniendo pictograma:', error);
        callback('');
      }
    );
  }





  

}
