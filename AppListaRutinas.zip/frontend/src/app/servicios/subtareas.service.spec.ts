import { TestBed } from '@angular/core/testing';

import { SubtareasService } from './subtareas.service';

describe('SubtareasService', () => {
  let service: SubtareasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SubtareasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
