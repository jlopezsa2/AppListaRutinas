import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';


interface Subtarea {
  id: number;
  nombre: string;
  completada: boolean;
  pictogramaUrl: string;
  horaurl: string;
  carita?: string;
}

interface Rutina {
  id: number;
  nombre: string;
  subtareas: Subtarea[];
}

interface Usuario {
  nombre: string;
  id: number;
  rutinas: Rutina[];
}

@Injectable({
  providedIn: 'root'
})

export class UsuariosService {

  private http = inject(HttpClient);
  private storageKey = 'usuarios';
  private apiUrl = 'http://localhost:3000/api/usuarios/';

  usuarios: Usuario[] = [{'nombre': 'Usuario', 'id': 0, 'rutinas': []}];
  usuariosBD: any[] = [];

  constructor() {
    this.cargarUsuarios();
    this.obtenerUsuarios();
    //this.guardarUsuarios();
  }

  obtenerUsuarios() {

  var users = this.ejemploCarga();
  

  this.ejemploCarga().subscribe((users) => {
    
    this.usuarios = users;
  });

  return this.usuarios;

  }

  obtenerUsuario(id: string) {
    return this.usuarios.find(u => u.id === parseInt(id));
  }

  /*agregarUsuario(nombre: string): void {
    const nuevoId = this.obtenerIdMax(this.usuarios) + 1;
    const nuevoUsuario = { nombre, id: nuevoId, rutinas: [] };
    this.usuarios.push(nuevoUsuario);
    this.guardarUsuarios();
  }*/


agregarUsuario(nombre: string): void {
    const nuevoUsuario: Usuario = {
      nombre,
      id: this.obtenerIdMax(this.usuarios) + 1, // Asignar un nuevo ID
      rutinas: []
    };

    this.http.post<Usuario>(this.apiUrl, nuevoUsuario).subscribe({
      next: (usuarioCreado) => {
        
        this.usuarios.push(usuarioCreado); // Añadimos el nuevo al array
      },
      error: (err) => {
        console.error('Error al crear usuario:', err);
      }
    });
  }
    

  obtenerIdMax(usuarios: any[]): number {
    let id = 0;
    for (let usuario of usuarios) {
      if (usuario.id > id) {
        id = usuario.id;
      }
    }
    return id;
  }

  cargarUsuarios(): void {
    //const usuariosGuardados = localStorage.getItem(this.storageKey);
    //this.usuarios = usuariosGuardados ? JSON.parse(usuariosGuardados) : this.usuarios;


  var users = this.ejemploCarga();
  

  this.ejemploCarga().subscribe((users) => {
    
    this.usuarios = users;
  });



  }





  ejemploCarga():Observable<Usuario[]>{ {

    return this.http.get<Usuario[]>(this.apiUrl);

  }

  }


  obtenerUsuarioDesdeBD(id: string): Observable<Usuario> {
  return this.http.get<Usuario>(`${this.apiUrl}${id}`);
}


actualizarUsuario(usuario: Usuario): Observable<Usuario> {
  return this.http.put<Usuario>(`${this.apiUrl}${usuario.id}`, usuario);
}


obtenerUsuarioPorId(id: number): Usuario | undefined {
  return this.usuarios.find(u => u.id === id);
}


obtenerUsuarioDesdeBackend(id: number) {
  return this.http.get<Usuario>(`${this.apiUrl}${id}`);
}




actualizarSubtarea(usuarioId: number, rutinaId: number, subtareaId: number, datos: any): Observable<any> {
  const url = `http://localhost:3000/api/usuarios/${usuarioId}/rutinas/${rutinaId}/subtareas/${subtareaId}`;
  return this.http.put(url, datos);
}


borrarUsuario(id: string) {
  return this.http.delete(`http://localhost:3000/api/usuarios/${id}`);
}



}






